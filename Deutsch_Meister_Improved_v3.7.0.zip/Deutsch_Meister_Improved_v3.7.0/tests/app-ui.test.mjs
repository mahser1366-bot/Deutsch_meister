import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const html = await readFile(new URL('../index.html', import.meta.url), 'utf8');
const app = await readFile(new URL('../js/app.js', import.meta.url), 'utf8');

test('the simplified app has five main pages and four bottom navigation items', () => {
  assert.equal((html.match(/class="view(?: active)?"/g) || []).length, 5);
  assert.equal((html.match(/class="nav-item/g) || []).length, 4);
});

test('CEFR is optional vocabulary metadata rather than a separate navigation section', () => {
  assert.match(html, /id="fieldLevel"/);
  assert.doesNotMatch(html, /data-nav="cefr"|data-nav="collections"/i);
});

test('the library uses bounded rendering and retains individual and batch deletion', () => {
  assert.match(app, /libraryLimit=100/);
  assert.match(app, /slice\(0,libraryLimit\)/);
  assert.match(html, /id="loadMoreWords"/);
  assert.match(app, /data-delete-import-batch/);
  assert.match(app, /data-delete=/);
});

test('CSV import remains in the Library and imported batches remain in Settings', () => {
  assert.match(html, /id="importCsvOpen"/);
  assert.match(html, /id="importCsv"/);
  assert.match(html, /id="importBatchList"/);
});

test('practice visibility depends on available imported data', () => {
  assert.match(app, /function renderPracticeAvailability\(\)/);
  assert.match(app, /import \{[^}]*inferPartOfSpeech[^}]*\} from '\.\/challenges\.js'/);
  assert.match(app, /new Set\(words\.filter\(w=>String\(w\.translation/);
  assert.match(app, /pluralOptions\(w,words\)\.length>=3/);
  assert.match(app, /buildVerbQuestions\(buildVerbBank\(words\)\)/);
});

test('the redesigned pages remove redundant home shortcuts and library filters', () => {
  assert.doesNotMatch(html, /home-links|categoryFilter|favoritesOnly/);
  assert.match(html, /id="wordSearch"/);
  assert.match(html, /id="addWordOpen"/);
  assert.match(html, /id="importCsvOpen"/);
  assert.match(html, /id="progressDue"/);
});

test('V3.7.0 retains neural voice diagnostics and safe model deletion controls', async () => {
  const html = await readFile(new URL('../index.html', import.meta.url), 'utf8');
  const app = await readFile(new URL('../js/app.js', import.meta.url), 'utf8');
  const worker = await readFile(new URL('../js/voice-worker.js', import.meta.url), 'utf8');
  assert.match(html, /id="voiceDiagnosticStatus"/);
  assert.match(html, /id="voiceDiagnosticLog"/);
  assert.match(html, /id="deleteVoiceModels"/);
  assert.match(html, /id="downloadVoiceModels"/);
  assert.match(app, /voiceModelsDisabled/);
  assert.match(app, /deleteNeuralVoice/);
  assert.match(worker, /action === 'delete'/);
  assert.match(worker, /reportStage\('Generating speech with ONNX'\)/);
});

test('V3.7.0 keeps the home dashboard separate from a full-screen flip-card review', () => {
  assert.match(html, /id="studyCardInner"/);
  assert.match(html, /class="study-card-face study-card-front"/);
  assert.match(html, /class="study-card-face study-card-back"/);
  assert.match(html, /id="endReview"/);
  assert.match(app, /classList\.toggle\('reviewing',hasCurrent\)/);
  assert.match(app, /classList\.add\('is-flipped'\)/);
  assert.match(app, /card-swipe-out/);
});

test('V3.7.0 includes tactile interaction states and respects reduced-motion preferences', async () => {
  const css = await readFile(new URL('../css/app.css', import.meta.url), 'utf8');
  assert.match(css, /rotateY\(180deg\)/);
  assert.match(css, /cardSwipeLeft/);
  assert.match(css, /cardSwipeRight/);
  assert.match(css, /prefers-reduced-motion: reduce/);
  assert.match(css, /reviewing-session \.bottom-nav/);
});


test('vocabulary editor exposes optional Persian, CEFR, tags, notes and all six present-tense persons', () => {
  for (const id of ['fieldPersian','fieldLevel','fieldTags','fieldNotes','fieldPresentIch','fieldPresentDu','fieldPresentEr','fieldPresentWir','fieldPresentIhr','fieldPresentSie']) {
    assert.match(html, new RegExp(`id=\"${id}\"`));
  }
  assert.match(app, /translationFa/);
  assert.match(app, /notes:\$\('fieldNotes'\)\.value\.trim\(\)/);
});

test('progress includes a month grid and real CEFR counts', () => {
  assert.match(html, /id="monthlyCalendar"/);
  assert.match(html, /id="cefrDistribution"/);
  assert.match(app, /monthCounts/);
  assert.match(app, /levelCounts/);
});

test('review persistence uses a single multi-store database transaction', async () => {
  assert.match(app, /await saveReview\(updated,log\)/);
  assert.match((await readFile(new URL('../js/db.js', import.meta.url), 'utf8')), /transact\(\['words', 'reviewLogs'\], 'readwrite'/);
});
