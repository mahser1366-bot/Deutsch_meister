import { readdir } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import { join } from 'node:path';

const jsFiles = (await readdir('js')).filter(name => name.endsWith('.js')).map(name => join('js', name));
jsFiles.push('sw.js');
for (const file of jsFiles) {
  const result = spawnSync(process.execPath, ['--check', file], { encoding: 'utf8' });
  if (result.status !== 0) {
    process.stderr.write(result.stderr || result.stdout || `Syntax check failed: ${file}\n`);
    process.exit(result.status || 1);
  }
  process.stdout.write(`Syntax OK: ${file}\n`);
}
